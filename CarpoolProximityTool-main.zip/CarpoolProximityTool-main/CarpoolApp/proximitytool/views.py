from django.shortcuts import render,redirect
from proximitytool.models import User


def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Check if the user exists in the database
        user_exists = User.objects.filter(username=username).exists()

        if user_exists and User.objects.filter(username=username, password=password).exists():
            # Perform actions for successful login
            return redirect('user_list')  # Change 'success_page' to your desired success page name

        elif not user_exists:
            # If the user doesn't exist, create a new user and save it in the database
            new_user = User(username=username, password=password)
            new_user.save()

            # Perform actions for successful registration
            return redirect('user_list')  # Change 'success_page' to your desired success page name
        
        else:
            return render(request, 'index.html', {'error_message': 'Login failed'})

    return render(request, 'index.html')


# Create your views here.
def user_list(request):
    users = User.objects.all()
    return render(request, 'user_list.html', {'users': users})